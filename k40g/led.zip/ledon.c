#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>
#define RED_BR "/sys/class/leds/red/brightness"
#define GREEN_BR "/sys/class/leds/green/brightness"
#define BLUE_BR "/sys/class/leds/blue/brightness"
int set_br(const char *path, int br) {
  int fd = open(path, O_RDWR);
  char buf[16] = {'\0'};
  sprintf(buf, "%d\n", br);
  write(fd, buf, strlen(buf));
  close(fd);
  return 0;
}

int main() {
  for (;;) {
    for (int i = 255, j = 1; i > 0; i-- | j++) {
      set_br(RED_BR, i);
      set_br(GREEN_BR, 0);
      set_br(BLUE_BR, j);
    }
    for (int i = 255, j = 1; i > 0; i-- | j++) {
      set_br(RED_BR, 0);
      set_br(GREEN_BR, j);
      set_br(BLUE_BR, i);
    }
    for (int i = 255, j = 1; i > 0; i-- | j++) {
      set_br(RED_BR, j);
      set_br(GREEN_BR, i);
      set_br(BLUE_BR, 0);
    }
  }
}
